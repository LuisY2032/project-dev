import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-MHG2NSFB.js";
import "./chunk-RNITANZT.js";
import "./chunk-EO42BBW2.js";
import "./chunk-6SXHT6SA.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
